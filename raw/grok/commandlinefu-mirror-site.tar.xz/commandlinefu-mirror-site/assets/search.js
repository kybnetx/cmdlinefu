(function () {
  var input = document.getElementById("q");
  var status = document.getElementById("search-status");
  var out = document.getElementById("search-results");
  if (!input || !out) return;

  var INDEX = null;
  var timer = null;
  var MAX = 80;

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function pathFor(row) {
    var slug = row[4] ? "/" + encodeURIComponent(row[4]) : "";
    return "/commands/view/" + row[0] + slug + "/";
  }
  function render(rows, q) {
    if (!q) {
      status.textContent = INDEX
        ? "Index loaded (" + INDEX.length.toLocaleString() + " commands). Type to search titles, code, and descriptions."
        : "";
      out.innerHTML = "";
      return;
    }
    status.textContent =
      rows.length === MAX
        ? "Showing the first " + MAX + " matches for “" + q + "”."
        : rows.length + " match" + (rows.length === 1 ? "" : "es") + " for “" + q + "”.";
    out.innerHTML = rows.map(function (r) {
      return (
        '<article class="card"><h2><a href="' + pathFor(r) + '">' + esc(r[1] || ("Command " + r[0])) +
        '</a></h2><p class="hit-code">' + esc(r[2] || "") + "</p></article>"
      );
    }).join("");
  }
  function search(q) {
    q = q.trim().toLowerCase();
    if (!INDEX) return;
    if (!q) { render([], ""); return; }
    var parts = q.split(/\s+/).filter(Boolean);
    var hits = [];
    for (var i = 0; i < INDEX.length && hits.length < MAX; i++) {
      var r = INDEX[i];
      var hay = ((r[1] || "") + "\n" + (r[2] || "") + "\n" + (r[3] || "")).toLowerCase();
      var ok = true;
      for (var j = 0; j < parts.length; j++) {
        if (hay.indexOf(parts[j]) === -1) { ok = false; break; }
      }
      if (ok) hits.push(r);
    }
    render(hits, q);
  }

  status.textContent = "Loading search index…";
  fetch("/data/search-index.json")
    .then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    })
    .then(function (data) {
      INDEX = data.rows;
      var params = new URLSearchParams(location.search);
      if (params.get("q") && !input.value) input.value = params.get("q");
      if (input.value) search(input.value);
      else render([], "");
    })
    .catch(function (err) {
      status.textContent = "Could not load the search index (" + err.message + ").";
    });

  input.addEventListener("input", function () {
    clearTimeout(timer);
    timer = setTimeout(function () { search(input.value); }, 120);
  });
  input.addEventListener("keydown", function (ev) {
    if (ev.key === "Enter") {
      ev.preventDefault();
      clearTimeout(timer);
      search(input.value);
    }
  });
})();
