#!/usr/bin/env python3
"""Generate a static unofficial commandlinefu.com mirror from commands.sqlite (or commands.json)."""

from __future__ import annotations

import argparse
import html
import json
import re
import shutil
import sqlite3
import sys
from pathlib import Path

PER_PAGE = 25
HERE = Path(__file__).resolve().parent


def esc(s) -> str:
    return html.escape("" if s is None else str(s), quote=True)


def slugify(title: str | None, url: str | None, cmd_id: int) -> str:
    if url:
        m = re.search(r"/commands/view/\d+/([^/?#]+)", url)
        if m:
            raw = m.group(1)
            raw = re.sub(r"[^A-Za-z0-9._-]+", "-", raw).strip("-.")
            if raw:
                return raw[:120]
    s = re.sub(r"[^a-z0-9]+", "-", (title or "").lower()).strip("-")
    return (s[:120] if s else str(cmd_id))


def load_commands(data_path: Path) -> list[dict]:
    if data_path.suffix == ".sqlite" or data_path.name.endswith(".sqlite"):
        conn = sqlite3.connect(data_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT * FROM commands").fetchall()
        conn.close()
        recs = []
        for r in rows:
            d = dict(r)
            for key in ("tags", "derived_tags", "functions"):
                val = d.get(key)
                if isinstance(val, str) and val:
                    try:
                        d[key] = json.loads(val)
                    except json.JSONDecodeError:
                        d[key] = []
                elif not val:
                    d[key] = []
            recs.append(d)
        return recs
    data = json.loads(data_path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise SystemExit(f"Unexpected JSON shape in {data_path}")
    return data


def browse_url(sort: str, offset: int) -> str:
    if sort == "votes":
        base = "/commands/browse/sort-by-votes"
    else:
        base = "/commands/browse"
    if offset:
        return f"{base}/{offset}/"
    return f"{base}/"


def tag_url(slug: str, sort: str = "date", offset: int = 0) -> str:
    base = f"/commands/tagged/{slug}"
    if sort == "votes":
        base += "/sort-by-votes"
    if offset:
        return f"{base}/{offset}/"
    return f"{base}/"


def view_url(rec: dict) -> str:
    slug = rec["_slug"]
    if slug:
        return f"/commands/view/{rec['id']}/{slug}/"
    return f"/commands/view/{rec['id']}/"


def wayback_href(rec: dict) -> str | None:
    if rec.get("wayback_url"):
        return rec["wayback_url"]
    url = rec.get("url")
    ts = rec.get("wayback_timestamp")
    if url and ts:
        return f"https://web.archive.org/web/{ts}id_/{url}"
    if url:
        return f"https://web.archive.org/web/*/{url}"
    return None


def source_label(src: str | None) -> str:
    return {
        "huggingface": "Hugging Face dump",
        "wayback-view": "Wayback view page",
        "wayback-listing": "Wayback listing",
    }.get(src or "", src or "unknown")


def pager(total: int, offset: int, sort: str, url_fn=None) -> str:
    url_fn = url_fn or (lambda s, off: browse_url(s, off))
    n_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    page = offset // PER_PAGE + 1
    parts = ['<nav class="pager" aria-label="Pagination">']
    if page > 1:
        parts.append(f'<a href="{esc(url_fn(sort, offset - PER_PAGE))}">← Previous</a>')
    else:
        parts.append('<span class="gap">← Previous</span>')

    def add(p: int, current: bool = False) -> None:
        off = (p - 1) * PER_PAGE
        if current:
            parts.append(f'<span class="current">{p}</span>')
        else:
            parts.append(f'<a href="{esc(url_fn(sort, off))}">{p}</a>')

    window = {1, n_pages, page, page - 1, page + 1, page - 2, page + 2}
    last_printed = 0
    for p in range(1, n_pages + 1):
        if p not in window:
            continue
        if last_printed and p > last_printed + 1:
            parts.append('<span class="gap">…</span>')
        add(p, p == page)
        last_printed = p
    if page < n_pages:
        parts.append(f'<a href="{esc(browse_url(sort, offset + PER_PAGE))}">Next →</a>')
    else:
        parts.append('<span class="gap">Next →</span>')
    parts.append("</nav>")
    return "\n".join(parts)


def layout(title: str, body: str, *, nav: str = "", description: str | None = None, extra_js: str = "") -> str:
    desc = description or "Unofficial offline mirror of commandlinefu.com one-liners."
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)}</title>
  <meta name="description" content="{esc(desc)}">
  <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
  <header class="top">
    <div class="wrap top-inner">
      <a class="brand" href="/">COMMANDLINE<span class="fu">FU</span><small>unofficial mirror</small></a>
      <nav class="menu">
        <a href="/commands/browse/"{' aria-current="page"' if nav == "browse" else ""}>Newest</a>
        <a href="/commands/browse/sort-by-votes/"{' aria-current="page"' if nav == "votes" else ""}>Top voted</a>
        <a href="/tags/"{' aria-current="page"' if nav == "tags" else ""}>Tags</a>
        <a href="/search/"{' aria-current="page"' if nav == "search" else ""}>Search</a>
        <a href="/about/"{' aria-current="page"' if nav == "about" else ""}>About</a>
      </nav>
    </div>
  </header>
  <main class="wrap">
{body}
  </main>
  <footer class="site">
    <div class="wrap">
      Unofficial mirror of community one-liners from
      <a href="http://www.commandlinefu.com/">commandlinefu.com</a>.
      Not affiliated with the original site.
      See <a href="/about/">About</a> for attribution and licensing notes.
    </div>
  </footer>
  <script src="/assets/app.js" defer></script>
  {extra_js}
</body>
</html>
"""


def command_block(code: str, compact: bool = False) -> str:
    return f"""<div class="cmd">
  <div class="cmd-bar"><span>{'$' if not compact else ''}</span><button type="button" class="copy" data-copy aria-label="Copy command">Copy</button></div>
  <div style="position:relative">
    <span class="prompt-mark" aria-hidden="true">$</span>
    <pre class="code"><code>{esc(code)}</code></pre>
  </div>
</div>"""


def rec_tag_chips(r: dict, limit: int = 8) -> str:
    chips = []
    for slug in r.get("tags") or []:
        chips.append(
            f'<li><a class="tag tag-original" href="{esc(tag_url(slug))}" '
            f'title="Original commandlinefu tag">{esc(slug)}</a></li>'
        )
    if not (r.get("tags") or []):
        for slug in r.get("derived_tags") or []:
            chips.append(
                f'<li><a class="tag tag-derived" href="{esc(tag_url(slug))}" '
                f'title="Derived from the command text; not tagged on the original site">{esc(slug)}</a></li>'
            )
    if not chips:
        return ""
    extra = ""
    if limit and len(chips) > limit:
        extra = f'<li class="tag-more">+{len(chips) - limit}</li>'
        chips = chips[:limit]
    return f'<ul class="tags">{"".join(chips)}{extra}</ul>'


def listing_page(
    recs: list[dict],
    *,
    sort: str,
    offset: int,
    total: int,
    heading: str | None = None,
    lede: str | None = None,
    nav: str | None = None,
    title: str | None = None,
    url_fn=None,
) -> str:
    if heading is None:
        if sort == "votes":
            heading = "All-time greats"
            lede = lede or f"All {total:,} commands, sorted by votes. Page {offset // PER_PAGE + 1}."
            nav = nav or "votes"
            title = title or f"Top voted commands · page {offset // PER_PAGE + 1}"
        else:
            heading = "Newest commands" if offset == 0 else "All commands"
            lede = lede or f"{total:,} commands, newest first. Page {offset // PER_PAGE + 1}."
            nav = nav or "browse"
            title = title or (
                "Commandlinefu unofficial mirror"
                if offset == 0
                else f"Browse commands · page {offset // PER_PAGE + 1}"
            )
    lede = lede or ""
    nav = nav or "browse"
    title = title or heading

    cards = []
    for r in recs:
        title_t = r.get("title") or f"Command {r['id']}"
        desc = r.get("description") or ""
        desc_html = f'<p class="desc">{esc(desc)}</p>' if desc else ""
        cards.append(
            f"""<article class="card">
  <h2><a href="{esc(view_url(r))}">{esc(title_t)}</a></h2>
  {command_block(r.get("code") or "", compact=True)}
  {desc_html}
  <div class="card-meta">
    <span class="votes">{esc(r.get("votes") or 0)} votes</span>
    <span>{esc(r.get("author") or "unknown")}</span>
    <span>{esc(r.get("date") or "")}</span>
  </div>
  {rec_tag_chips(r, limit=6)}
</article>"""
        )
    body = f"""    <h1>{esc(heading)}</h1>
    <p class="lede">{lede if lede.startswith("<") else esc(lede)}</p>
    {"".join(cards)}
    {pager(total, offset, sort, url_fn=url_fn)}
"""
    return layout(title, body, nav=nav, description=re.sub(r"<[^>]+>", "", lede))


def command_page(r: dict) -> str:
    title_t = r.get("title") or f"Command {r['id']}"
    desc = r.get("description")
    ai_flag = bool(r.get("ai_generated_description"))
    ai_text = r.get("ai_description")
    parts = [
        f"    <h1>{esc(title_t)}</h1>",
        '    <div class="meta-bar">',
        f'      <span class="votes">{esc(r.get("votes") or 0)} votes</span>',
        f"      <span>by {esc(r.get('author') or 'unknown')}</span>",
        f"      <span>{esc(r.get('date') or '')}</span>",
        f'      <span class="pill">{esc(source_label(r.get("source")))}</span>',
        "    </div>",
        f"    {command_block(r.get('code') or '')}",
    ]
    if desc:
        parts.append(f'    <div class="desc"><p>{esc(desc)}</p></div>')
    if ai_flag and ai_text:
        parts.append(
            '    <aside class="ai-box" role="note">'
            "<strong>AI-generated description</strong>"
            "This text was produced by an automated model in a third-party dataset "
            "because no original author description was available. It is not written "
            f"by the command’s author.<p>{esc(ai_text)}</p></aside>"
        )
    chips_html = rec_tag_chips(r, limit=0)
    if chips_html:
        parts.append(f"    {chips_html}")

    original = r.get("url") or f"http://www.commandlinefu.com/commands/view/{r['id']}"
    wb = wayback_href(r)
    links = [f'<a href="{esc(original)}">Original on commandlinefu.com</a>']
    if wb:
        links.append(f'<a href="{esc(wb)}">Wayback Machine copy</a>')
    parts.append(f'    <p class="links" style="margin-top:1.1rem">{"".join(links)}</p>')
    body = "\n".join(parts)
    return layout(f"{title_t} · commandlinefu mirror", body, description=desc or title_t)


def search_page() -> str:
    body = """    <h1>Search</h1>
    <p class="lede">Search titles, command text, and descriptions in this offline copy. Matching is literal and case-insensitive.</p>
    <div class="search-box">
      <input id="q" type="search" placeholder="e.g. rsync, sudo, ssh" autocomplete="off" autofocus>
    </div>
    <p id="search-status"></p>
    <div id="search-results"></div>
"""
    extra = '<script src="/assets/search.js" defer></script>'
    return layout("Search · commandlinefu mirror", body, nav="search", extra_js=extra)


def about_page(total: int, newest: str, oldest: str, by_src: dict) -> str:
    body = f"""    <div class="about">
      <h1>About this mirror</h1>
      <p>This is an unofficial, static, offline copy of community shell one-liners originally published on
      <a href="http://www.commandlinefu.com/">commandlinefu.com</a>. It is meant to be served by Apache on a local machine.
      It is <strong>not affiliated with</strong> the original site or its maintainers.</p>
      <p>This copy contains <strong>{total:,}</strong> commands, dated from {esc(oldest)} through {esc(newest)}
      (Hugging Face dump: {by_src.get('huggingface', 0):,}; Wayback view pages: {by_src.get('wayback-view', 0):,};
      Wayback listings: {by_src.get('wayback-listing', 0):,}).</p>

      <h2>Attribution</h2>
      <p>Content originates from <strong>commandlinefu.com</strong> and its <strong>original authors</strong>.
      Each command page links back to the original URL and, where available, a Wayback Machine snapshot.
      Please credit the authors if you reuse a one-liner.</p>

      <h2>Licensing notes</h2>
      <p>No formal terms-of-use or Creative Commons license was found on the original site. Treat this as
      <strong>informal permission only</strong>, not a license you can re-grant:</p>
      <blockquote>The site’s API page described the listings as available “in a variety of different formats for you to do what you like with.”</blockquote>
      <blockquote>The Chinese community port tg123/commandlinefu.cn quotes the original owner, David Winterbottom: “You're welcome to re-publish the commandlinefu content.”</blockquote>
      <p>The later maintainer was Jon Hendren (DA Holdings / danstools.com, per the site FAQ). A later Hugging Face dataset packaged many of these commands and tagged that packaging CC0; that tag is the compiler’s, not a license grant from the original authors. AI-written descriptions from that dataset are shown only in a clearly labeled box and are never mixed into the original description field.</p>
      <p>Do not treat this mirror as freely relicensable. Keep attribution, and be prepared to take content down at a rights-holder’s request.</p>

      <h2>Tags</h2>
      <p>Where the original site tagged a command, this mirror uses those tags
      (from the May 2017 Archive.org WARC of commandlinefu.com and later Wayback snapshots).
      Commands that were never tagged get <strong>derived tags</strong>, inferred from the
      programs the command actually invokes (for example <code>find</code>, <code>awk</code>,
      <code>ssh</code>). Derived tags are shown with a lighter, dashed style and a tooltip;
      they are stored separately from original tags and are never mixed into the original
      <code>tags</code> field. A few tiny or noisy slugs (single letters, bare numbers,
      shell keywords like <code>do</code>/<code>for</code>) are omitted from the
      <a href="/tags/">tag index</a> but may still appear on a command page if the original
      site used them.</p>

      <h2>Known gaps</h2>
      <p>The October 2026 live site listed 14,235 commands. This dataset has {total:,} IDs because it unions the Hugging Face dump with older Wayback-only pages (some of which the dump had omitted) and later 2024–2026 commands recovered from Wayback. Browse pagination in the 2024–2026 Wayback crawl was sparse, so a few late commands may still be missing. Some recovered pages include spam submissions, kept as they appeared.</p>
    </div>
"""
    return layout("About · commandlinefu mirror", body, nav="about")


def not_found_page() -> str:
    body = """    <h1>Page not found</h1>
    <p class="lede">That URL is not in this mirror. Try <a href="/commands/browse/">browsing</a> or <a href="/search/">search</a>.</p>
"""
    return layout("Not found · commandlinefu mirror", body)


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def chunk(items: list, size: int):
    for i in range(0, len(items), size):
        yield i, items[i : i + size]



JUNK_INDEX_SLUGS = {
    "if", "then", "fi", "else", "elif", "for", "while", "until", "do", "done",
    "case", "esac", "in", "select", "function", "time", "coproc",
    "and", "or", "not", "the", "to", "of", "on", "at", "as", "by", "from",
    "with", "this", "that", "is", "it", "be",
    "_",
}


def include_in_index(slug: str, n_original: int, n_derived: int) -> bool:
    if not slug or len(slug) <= 1:
        return False
    if slug.isdigit() or re.fullmatch(r"[\d._-]+", slug):
        return False
    if slug.lower() in JUNK_INDEX_SLUGS:
        return False
    if n_original >= 1:
        return True
    return n_derived >= 2


def load_catalog(data_path: Path, recs: list[dict]) -> list[dict]:
    """Load tag_catalog from sqlite or tags_catalog.json, else synthesize from records."""
    catalog = []
    sqlite_path = data_path if data_path.suffix == ".sqlite" else None
    if sqlite_path and sqlite_path.exists():
        try:
            conn = sqlite3.connect(sqlite_path)
            rows = conn.execute(
                "SELECT slug, label, ids, n_original, n_derived FROM tag_catalog"
            ).fetchall()
            conn.close()
            for slug, label, ids, n_o, n_d in rows:
                try:
                    idlist = json.loads(ids) if ids else []
                except json.JSONDecodeError:
                    idlist = []
                catalog.append(
                    {
                        "slug": slug,
                        "label": label or slug,
                        "ids": idlist,
                        "n_original": int(n_o or 0),
                        "n_derived": int(n_d or 0),
                    }
                )
        except sqlite3.Error:
            catalog = []
    if not catalog:
        json_cand = data_path.parent / "tags_catalog.json"
        if json_cand.exists():
            catalog = json.loads(json_cand.read_text(encoding="utf-8"))
    if not catalog:
        counts_o: dict[str, int] = {}
        counts_d: dict[str, int] = {}
        for r in recs:
            for s in r.get("tags") or []:
                counts_o[s] = counts_o.get(s, 0) + 1
            for s in r.get("derived_tags") or []:
                counts_d[s] = counts_d.get(s, 0) + 1
        slugs = set(counts_o) | set(counts_d)
        catalog = [
            {
                "slug": s,
                "label": s,
                "ids": [],
                "n_original": counts_o.get(s, 0),
                "n_derived": counts_d.get(s, 0),
            }
            for s in sorted(slugs)
        ]
    return catalog


def tags_index_page(catalog: list[dict], *, n_orig_cmds: int, n_der_cmds: int) -> str:
    visible = [
        c
        for c in catalog
        if include_in_index(c["slug"], c.get("n_original", 0), c.get("n_derived", 0))
    ]
    totals = [c["n_original"] + c["n_derived"] for c in visible]
    max_n = max(totals) if totals else 1
    top = sorted(visible, key=lambda c: (-(c["n_original"] + c["n_derived"]), c["slug"]))[:48]

    def cloud_link(c: dict) -> str:
        n = c["n_original"] + c["n_derived"]
        # 0.85rem .. 1.7rem
        size = 0.85 + 0.85 * (n / max_n) ** 0.5
        kind = "tag-original" if c["n_original"] else "tag-derived"
        title = (
            f"{n} commands"
            + (f" ({c['n_original']} original tags)" if c["n_original"] and c["n_derived"] else "")
        )
        if not c["n_original"]:
            title += " (derived from command text)"
        return (
            f'<a class="cloud-tag {kind}" href="{esc(tag_url(c["slug"]))}" '
            f'title="{esc(title)}" style="font-size:{size:.2f}rem">{esc(c.get("label") or c["slug"])}'
            f"<small>{n}</small></a>"
        )

    cloud = "\n".join(cloud_link(c) for c in top)

    # alphabetical groups
    groups: dict[str, list] = {}
    for c in sorted(visible, key=lambda c: c["slug"]):
        letter = (c["slug"][:1] or "#").upper()
        if not letter.isalpha():
            letter = "#"
        groups.setdefault(letter, []).append(c)
    letters = "".join(
        f'<a href="#letter-{esc(L)}">{esc(L)}</a>' if L in groups else f"<span>{esc(L)}</span>"
        for L in list("ABCDEFGHIJKLMNOPQRSTUVWXYZ") + ["#"]
    )
    blocks = []
    for L, items in groups.items():
        lis = []
        for c in items:
            n = c["n_original"] + c["n_derived"]
            kind = "tag-original" if c["n_original"] else "tag-derived"
            hint = "" if c["n_original"] else ' title="Derived from command text"'
            lis.append(
                f'<li><a class="tag {kind}" href="{esc(tag_url(c["slug"]))}"{hint}>'
                f'{esc(c.get("label") or c["slug"])}</a> '
                f'<span class="count">{n}</span></li>'
            )
        blocks.append(
            f'<section class="tag-letter" id="letter-{esc(L)}"><h2>{esc(L)}</h2>'
            f'<ul class="tag-index">{"".join(lis)}</ul></section>'
        )
    body = f"""    <h1>Tags</h1>
    <p class="lede">{len(visible):,} tags across {n_orig_cmds:,} originally tagged commands
    and {n_der_cmds:,} commands whose tags were derived from the command text.
    Derived-only tags are shown with a dashed outline. Tiny or noisy slugs are omitted here.</p>
    <h2>Top tags</h2>
    <div class="tag-cloud">
      {cloud}
    </div>
    <nav class="letter-nav" aria-label="Jump to letter">{letters}</nav>
    {"".join(blocks)}
"""
    return layout("Tags · commandlinefu mirror", body, nav="tags", description="Tag index for the unofficial commandlinefu mirror.")


def generate(data_path: Path, out: Path, assets: Path) -> None:
    recs = load_commands(data_path)
    for r in recs:
        r["_slug"] = slugify(r.get("title"), r.get("url"), int(r["id"]))
        r["id"] = int(r["id"])
        r["votes"] = int(r.get("votes") or 0)

    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    # assets
    (out / "assets").mkdir()
    for name in ("style.css", "app.js", "search.js"):
        src = assets / name
        if not src.exists():
            raise SystemExit(f"Missing asset {src}")
        shutil.copy2(src, out / "assets" / name)

    by_id = {r["id"]: r for r in recs}
    newest = sorted(recs, key=lambda r: ((r.get("date") or ""), r["id"]), reverse=True)
    by_votes = sorted(recs, key=lambda r: (r["votes"], r["id"]), reverse=True)
    total = len(recs)

    # listing pages
    for sort, ordered in (("date", newest), ("votes", by_votes)):
        for offset, page_rows in chunk(ordered, PER_PAGE):
            html_page = listing_page(page_rows, sort=sort, offset=offset, total=total)
            dest = out / browse_url(sort, offset).lstrip("/") / "index.html"
            write(dest, html_page)
    # home is the newest listing
    write(out / "index.html", listing_page(newest[:PER_PAGE], sort="date", offset=0, total=total))

    # command pages + slug stubs
    for r in recs:
        page = command_page(r)
        write(out / "commands" / "view" / str(r["id"]) / "index.html", page)
        slug = r["_slug"]
        if slug:
            stub = (
                "<!DOCTYPE html>\n<html lang=\"en\"><head>"
                f'<meta charset="utf-8"><title>{esc(r.get("title") or r["id"])}</title>'
                f'<link rel="canonical" href="/commands/view/{r["id"]}/">'
                '<meta http-equiv="refresh" content="0;url=../">'
                "</head><body>"
                f'<p>Redirecting to <a href="../">command {esc(r["id"])}</a>.</p>'
                "</body></html>\n"
            )
            write(out / "commands" / "view" / str(r["id"]) / slug / "index.html", stub)

    # Tag pages
    catalog = load_catalog(data_path, recs)
    by_tag: dict[str, list] = {}
    for r in newest:
        r.setdefault("tags", [])
        r.setdefault("derived_tags", [])
        slugs = r.get("tags") or r.get("derived_tags") or []
        for s in slugs:
            by_tag.setdefault(s, []).append(r)
    n_orig_cmds = sum(1 for r in recs if r.get("tags"))
    n_der_cmds = sum(1 for r in recs if (not r.get("tags")) and r.get("derived_tags"))
    write(out / "tags" / "index.html", tags_index_page(catalog, n_orig_cmds=n_orig_cmds, n_der_cmds=n_der_cmds))

    n_tag_pages = 0
    for c in catalog:
        slug = c["slug"]
        members = by_tag.get(slug) or []
        if not members:
            continue
        votes_m = sorted(members, key=lambda r: (r["votes"], r["id"]), reverse=True)
        label = c.get("label") or slug
        n = len(members)
        orig_n = int(c.get("n_original") or 0)
        kind = "original commandlinefu tags" if orig_n else "tags derived from command text"
        for sort, ordered in (("date", members), ("votes", votes_m)):
            def url_fn(s, off, slug=slug):
                return tag_url(slug, s, off)
            for offset, page_rows in chunk(ordered, PER_PAGE):
                page_no = offset // PER_PAGE + 1
                if sort == "votes":
                    sort_links = (
                        f'<a href="{esc(tag_url(slug))}">Newest</a> · <strong>Top voted</strong>'
                    )
                    lede_text = (
                        f"{n:,} commands tagged {label} ({kind}), sorted by votes. Page {page_no}."
                    )
                else:
                    sort_links = (
                        f"<strong>Newest</strong> · "
                        f'<a href="{esc(tag_url(slug, "votes"))}">Top voted</a>'
                    )
                    lede_text = (
                        f"{n:,} commands tagged {label} ({kind}), newest first. Page {page_no}."
                    )
                lede_html = f"<span>{esc(lede_text)} <span class=\"sort-switch\">{sort_links}</span></span>"
                html_page = listing_page(
                    page_rows,
                    sort=sort,
                    offset=offset,
                    total=n,
                    heading=f"Tag: {label}",
                    lede=lede_html,
                    nav="tags",
                    title=f"{label} · tags · page {page_no}",
                    url_fn=url_fn,
                )
                dest = out / tag_url(slug, sort, offset).lstrip("/") / "index.html"
                write(dest, html_page)
                n_tag_pages += 1
        # Stubs so /commands/tagged/<id>/<slug>/ works without rewrite
        for tid in c.get("ids") or []:
            try:
                tid_i = int(tid)
            except (TypeError, ValueError):
                continue
            stub = (
                "<!DOCTYPE html>\n<html lang=\"en\"><head>"
                f'<meta charset="utf-8"><title>{esc(label)}</title>'
                f'<link rel="canonical" href="{esc(tag_url(slug))}">'
                f'<meta http-equiv="refresh" content="0;url={esc(tag_url(slug))}">'
                "</head><body>"
                f'<p>Redirecting to <a href="{esc(tag_url(slug))}">{esc(label)}</a>.</p>'
                "</body></html>\n"
            )
            write(out / "commands" / "tagged" / str(tid_i) / slug / "index.html", stub)

    # search index (compact arrays)
    index_rows = []
    for r in newest:
        desc = r.get("description") or ""
        if len(desc) > 280:
            desc = desc[:277] + "…"
        index_rows.append([r["id"], r.get("title") or "", r.get("code") or "", desc, r["_slug"]])
    write(out / "data" / "search-index.json", json.dumps({"rows": index_rows}, ensure_ascii=False, separators=(",", ":")))

    write(out / "search" / "index.html", search_page())

    by_src = {}
    for r in recs:
        by_src[r.get("source") or "unknown"] = by_src.get(r.get("source") or "unknown", 0) + 1
    dates = [r.get("date") for r in recs if r.get("date")]
    write(out / "about" / "index.html", about_page(total, max(dates) if dates else "?", min(dates) if dates else "?", by_src))
    write(out / "404.html", not_found_page())

    htaccess = r"""DirectoryIndex index.html
Options -Indexes +FollowSymLinks
ErrorDocument 404 /404.html

<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  # Legacy /commands/view/<id>/<slug> → the id page.
  # Skip index.html and use [END] so per-directory rewrites do not loop.
  RewriteRule ^commands/view/([0-9]+)/index\.html$ - [L]
  RewriteRule ^commands/view/([0-9]+)/.+$ /commands/view/$1/index.html [END]
  # Legacy /commands/tagged/<id>/<slug>/… → /commands/tagged/<slug>/…
  RewriteRule ^commands/tagged/([0-9]+)/([^/]+)/(.*)$ /commands/tagged/$2/$3 [END]
  RewriteRule ^commands/tagged/([0-9]+)/([^/]+)/?$ /commands/tagged/$2/ [END]
</IfModule>

<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css text/javascript application/javascript application/json
</IfModule>

<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/html "access plus 10 minutes"
  ExpiresByType text/css "access plus 7 days"
  ExpiresByType application/javascript "access plus 7 days"
  ExpiresByType application/json "access plus 1 hour"
</IfModule>

<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set Referrer-Policy "same-origin"
</IfModule>
"""
    write(out / ".htaccess", htaccess)
    print(f"Wrote {total} commands and {n_tag_pages} tag listing pages into {out}", file=sys.stderr)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--data",
        type=Path,
        default=None,
        help="Path to commands.sqlite or commands.json (default: ../commands.sqlite next to this script)",
    )
    ap.add_argument(
        "--out",
        type=Path,
        default=HERE / "public",
        help="Output directory (default: ./public)",
    )
    args = ap.parse_args(argv)
    data = args.data
    if data is None:
        for cand in (HERE.parent / "commands.sqlite", HERE / "commands.sqlite", Path("commands.sqlite")):
            if cand.exists():
                data = cand
                break
        if data is None:
            raise SystemExit("Cannot find commands.sqlite; pass --data")
    generate(data.resolve(), args.out.resolve(), HERE / "assets")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
