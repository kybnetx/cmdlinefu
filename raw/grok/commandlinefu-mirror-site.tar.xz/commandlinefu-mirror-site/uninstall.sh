#!/bin/bash
# Remove the unofficial commandlinefu Apache site installed by install.sh.
set -euo pipefail

DEST="/var/www/commandlinefu-mirror"
SITE_AVAIL="/etc/apache2/sites-available/commandlinefu-mirror.conf"
STATE_DIR="/var/lib/commandlinefu-mirror"
FLAG="$STATE_DIR/disabled-000-default"

die() { echo "uninstall.sh: $*" >&2; exit 1; }
if [[ "$(id -u)" -ne 0 ]]; then
  die "run as root, e.g.: sudo $0"
fi

if [[ -e /etc/apache2/sites-enabled/commandlinefu-mirror.conf ]]; then
  a2dissite commandlinefu-mirror >/dev/null || true
fi
rm -f "$SITE_AVAIL"

if [[ -f "$FLAG" ]] && [[ ! -e /etc/apache2/sites-enabled/000-default.conf ]]; then
  echo "Re-enabling Apache's default site."
  a2ensite 000-default >/dev/null || true
fi

if [[ -f "$STATE_DIR/added-hosts" ]]; then
  echo "Removing the commandlinefu.local line we added to /etc/hosts."
  tmp="$(mktemp)"
  awk '
    /^# unofficial commandlinefu static mirror$/ { skip=1; next }
    skip && /^127\.0\.0\.1 commandlinefu\.local$/ { skip=0; next }
    { skip=0; print }
  ' /etc/hosts > "$tmp"
  cat "$tmp" > /etc/hosts
  rm -f "$tmp" "$STATE_DIR/added-hosts"
fi

rm -rf "$DEST"
rm -f "$FLAG"
rmdir "$STATE_DIR" 2>/dev/null || true

if command -v apache2ctl >/dev/null 2>&1; then
  apache2ctl configtest || true
  systemctl reload apache2 2>/dev/null || apache2ctl graceful || true
fi

echo "Uninstalled the commandlinefu mirror vhost and /var/www/commandlinefu-mirror."
